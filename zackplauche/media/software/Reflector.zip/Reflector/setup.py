from setuptools import setup, find_packages

setup(
	name="reflector",
	version="0.0.1",
	author="Zack Plauché",
	author_email="zackplauche@gmail.com",
	description="An app that walks the user through different reflection thought processes made by his/herself.",
	packages=find_packages()
)
