


class Reflector:



    def __init__(self, questions={}):
        if type(questions) is not dict:
            raise TypeError(f"Must be a dict containing format\{question:question_type}, not a {type(questions)}.")
        elif not str in
        self.questions = questions

    def add_questions(self):
        question_types = ['unordered list', 'orderd list', 'limited list', 'short text', 'long text']
        while True:
            new_question = input("What question would you like to reflect upon?\n")
            if new_question == "":
                break
            else:
                print(f"\nWhat type of answer would you like?\n({' / '.join(question_types)})n")
                question_type = input()
                questions[new_question]

    def text_answer(self, questions=None):
        pass

    def list_answer(self, questions -> list):
        pass


    def reflect():
        pass
