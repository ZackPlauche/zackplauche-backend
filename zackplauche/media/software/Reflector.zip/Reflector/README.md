# Reflector

Reflector is a system that allows users to walkthrough different thought processes by smart individuals.
